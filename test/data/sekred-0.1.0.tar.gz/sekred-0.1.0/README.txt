(* OASIS_START *)
(* DO NOT EDIT (digest: 0e43a0f2d0d3273c6881cc654b3e9150) *)
This is the README file for the sekred distribution.

(C) 2013 Sylvain Le Gall

Password manager for automatic installation.

This program helps to manage passwords set automatically and stored in a
semi-secure way.

It is not a fully secured storage for password because only the Unix ACL
system protects the secret. Typical usage is to store password for MySQL
databases.

The system is designed to be a companion tool for puppet.

See the files INSTALL.txt for building and installation instructions. 

Home page: http://sekred.forge.ocamlcore.org/


(* OASIS_STOP *)
