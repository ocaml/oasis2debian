(******************************************************************************)
(* dlnasync: Synchronize your media collection with a DLNA server.            *)
(*                                                                            *)
(* Copyright (C) 2013, Sylvain Le Gall                                        *)
(*                                                                            *)
(* This library is free software; you can redistribute it and/or modify it    *)
(* under the terms of the GNU Lesser General Public License as published by   *)
(* the Free Software Foundation; either version 2.1 of the License, or (at    *)
(* your option) any later version, with the OCaml static compilation          *)
(* exception.                                                                 *)
(*                                                                            *)
(* This library is distributed in the hope that it will be useful, but        *)
(* WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY *)
(* or FITNESS FOR A PARTICULAR PURPOSE. See the file COPYING for more         *)
(* details.                                                                   *)
(*                                                                            *)
(* You should have received a copy of the GNU Lesser General Public License   *)
(* along with this library; if not, write to the Free Software Foundation,    *)
(* Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301 USA              *)
(******************************************************************************)

open FileUtil
module UnixPath = FilePath.UnixPath

module ExternalCommand =
struct
  type t =
      {
        name: string;
        f: string list -> unit;
      }

  let db = Hashtbl.create 13

  let override name f =
    Hashtbl.replace db name {name= name; f = f}

  let command_line name args =
    String.concat " " (name :: args)

  let runner name args =
    let _, status =
      Unix.waitpid []
        (Unix.create_process name (Array.of_list (name :: args))
           Unix.stdin Unix.stdout Unix.stderr)
    in
      match status with
        | Unix.WEXITED 0 ->
            ()
        | Unix.WEXITED n | Unix.WSIGNALED n | Unix.WSTOPPED n ->
            failwith
              (Printf.sprintf
                 "Unexpected exit code %d for command: %s."
                 n (command_line name args))

  let make name =
    override name (fun args -> runner name args);
    fun () -> Hashtbl.find db name

  let run t logger args =
    let start_time = Unix.gettimeofday () in
      Logger.infof logger "Running command: %s." (command_line t.name args);
      t.f args;
      Logger.infof logger "Done with command: %s (time spent: %0.2f)."
        (command_line t.name args) (Unix.gettimeofday () -. start_time)

  let args () =
    Hashtbl.fold
      (fun name _ lst ->
         ("-"^name,
          Arg.String (fun str -> override name (runner str)),
          (Printf.sprintf "exec Use this program to replace %s." name))
         :: lst)
      db
      []

  let mock name f =
    {name = name; f = f}
end

type conf =
    {
      local_rootdir: string;
      local_dirs: string list;
      ftpfs: Netfs.stream_fs;
      logger: Logger.t;
      avconv: ExternalCommand.t;
    }

module Entry =
struct
  type t =
      {
        filename: string;
        timestamp: float;
        size: int64;
        filename_local: string; (* TODO: option *)
        need_convert: bool;
      }

  let to_string t =
    Printf.sprintf "%S <- %S %f %Ld %b"
      t.filename t.filename_local t.timestamp t.size t.need_convert

  let dump t =
    Printf.sprintf "%S %f %Ld"
      t.filename t.timestamp t.size

  let parse str =
    Scanf.sscanf str "%S %f %Ld"
      (fun filename timestamp size ->
         {
           filename = filename;
           timestamp = timestamp;
           size = size;
           filename_local = "<none>";
           need_convert = false;
         })

  let of_file conf fn =
    let rec remove_trailing_slash fn =
      let strlen = String.length fn in
        if strlen > 0 && fn.[strlen - 1] = '/' then
          remove_trailing_slash (String.sub fn 0 (strlen - 1))
        else
          fn
    in
    let filename =
      "/"^(FilePath.make_relative
             (remove_trailing_slash conf.local_rootdir) fn)
    in
    let st = Unix.LargeFile.stat fn in
      {
        filename = filename;
        timestamp = st.Unix.LargeFile.st_mtime;
        size = st.Unix.LargeFile.st_size;
        filename_local = fn;
        need_convert = false;
      }

  let compare t1 t2 =
    let norm t = {t with filename_local = ""; need_convert = false} in
      Pervasives.compare (norm t1) (norm t2)

  let change_filename t f =
    let fn = f t.filename in
    if fn <> t.filename then
      {t with filename = fn; need_convert = true}
    else
      t

end

module SetEntry = Set.Make(Entry)

module SetString =
struct
  include Set.Make(String)

  let of_list =
    List.fold_left
      (fun st ext -> add (String.lowercase ext) st)
      empty

  let match_extension st fn =
     let ext = String.lowercase (FilePath.get_extension fn) in
       mem ext st
end

module MapString = Map.Make(String)

let no_convert_extensions =
  SetString.of_list ["mp4"]

let convert_extensions =
  SetString.of_list ["wmv"; "ogv"; "ogg"; "avi"]

let ignore_extensions =
  SetString.of_list ["tmp"]

let scan_local conf =
  let find_media_files lst dn =
    if not (Sys.file_exists dn) then
      failwith (Printf.sprintf "Directory '%s' doesn't exist." dn);
    if not (Sys.is_directory dn) then
      failwith (Printf.sprintf "'%s' is not a directory." dn);
    FileUtil.find Is_file
      dn
      (fun lst fn ->
         let entry () = Entry.of_file conf fn in
           if SetString.match_extension no_convert_extensions fn then begin
             Logger.infof conf.logger "Considering '%s'." fn;
             entry () :: lst
           end else if SetString.match_extension
                         convert_extensions fn then begin
             Logger.infof conf.logger "Considering '%s' with conversion." fn;
             Entry.change_filename
               (entry ())
               (fun fn -> FilePath.replace_extension fn "mp4") :: lst
          end else if SetString.match_extension
                        ignore_extensions fn then begin
             Logger.infof conf.logger "Ignoring '%s'." fn;
             lst
           end else begin
             Logger.warningf conf.logger "Don't know what to do with '%s'." fn;
             lst
           end)
      lst
  in
  let lst =
    if conf.local_dirs = [] then begin
      find_media_files [] conf.local_rootdir
    end else begin
      List.fold_left find_media_files []
        (List.rev_map
           (Filename.concat conf.local_rootdir)
           conf.local_dirs)
    end
  in
  let _, set_entry =
    List.fold_left
      (fun (map_source, set_entry) entry ->
         let filename = entry.Entry.filename in
         let new_source = entry.Entry.filename_local in
           if MapString.mem entry.Entry.filename map_source then begin
             let old_source = MapString.find entry.Entry.filename map_source in
               failwith
                 (Printf.sprintf
                    "Duplicate entry for target '%s': '%s' and '%s'."
                    filename old_source new_source)
           end;
           MapString.add filename new_source map_source,
           SetEntry.add entry set_entry)
      (MapString.empty, SetEntry.empty)
      lst
  in
    set_entry

let remote_db_fn = "/dlnasync.txt"

let remote_file_exists conf fn =
  (* Workaround because ftpfs#test doesn't work. *)
  try
    let chn_in = conf.ftpfs#read [] fn in
      chn_in#close_in ();
      true
  with _ ->
    false

let remote_dir_exists conf dn =
  (* Workaround because ftpfs#test doesn't work. *)
  try
    let _lst : string list = conf.ftpfs#readdir [] dn in
      true
  with _ ->
    false

let commit_db conf set =
  let remote_db_fn_tmp = remote_db_fn ^ ".tmp" in
  let chn_out = conf.ftpfs#write [`Create; `Truncate] remote_db_fn_tmp in
    Logger.infof conf.logger "Creating temporary remote db: %S."
      remote_db_fn_tmp;
    SetEntry.iter
      (fun entry ->
         chn_out#output_string (Entry.dump entry);
         chn_out#output_char '\n')
      set;
    chn_out#close_out ();
    Logger.infof conf.logger "Commiting remote db: %S." remote_db_fn;
    conf.ftpfs#rename [] remote_db_fn_tmp remote_db_fn

let load_db conf =
  let ftpfs = conf.ftpfs in
  if remote_file_exists conf remote_db_fn then begin
    let chn_in = ftpfs#read [] remote_db_fn in
    let rset = ref SetEntry.empty in
    let () =
      try
        while true do
          let line = chn_in#input_line () in
            if line <> "" then
              rset := SetEntry.add (Entry.parse line) !rset;
        done
      with End_of_file ->
        chn_in#close_in ()
    in
      !rset
  end else begin
    SetEntry.empty
  end

let remove conf set entry =
  let () =
    Logger.infof conf.logger "Remove remote file: %S" (Entry.to_string entry);
    conf.ftpfs#remove [] entry.Entry.filename
  in
  let set' = SetEntry.remove entry set in
    commit_db conf set';
    set'

let upload conf set entry =
  (* Create directory structure. *)
  let rec mkdir_parent dn =
    if not (remote_dir_exists conf dn) then begin
      Logger.infof conf.logger "Creating directory '%s'." dn;
      try
        conf.ftpfs#mkdir [`Path] dn
      with (Unix.Unix_error(error, str1, str2) as e) ->
        begin
          (* This error can denote a real problem or just the fact that target
           * FTP doesn't support `Path.
           *)
          Logger.warningf conf.logger
            "Error while creating directory: %s: %S, %S"
            (Unix.error_message error) str1 str2;
          let dn' = UnixPath.dirname dn in
            if dn = dn' then begin
              (* Raise a fix point, cannot go further. *)
              raise e
            end else begin
              mkdir_parent dn';
              conf.ftpfs#mkdir [] dn
            end
        end
    end
  in

  let upload fn =
    mkdir_parent (UnixPath.dirname entry.Entry.filename);
    Logger.infof conf.logger "Uploading '%s' to '%s'." fn entry.Entry.filename;
    conf.ftpfs#write_file [`Binary; `Create; `Truncate] entry.Entry.filename
      (object
         method filename = fn
         method close = ignore
       end);
    Logger.infof conf.logger "Done uploading '%s'." entry.Entry.filename
  in
  let () =
    if entry.Entry.need_convert then begin
      let local_fn = entry.Entry.filename_local in
      let tmp_fn = FilePath.replace_extension local_fn "tmp" in
        if Sys.file_exists tmp_fn then
          Sys.remove tmp_fn;
        Logger.infof conf.logger "Converting '%s' to '%s'." local_fn tmp_fn;
        ExternalCommand.run conf.avconv
          conf.logger
          ["-i"; entry.Entry.filename_local;
           "-acodec"; "ac3";
           "-ab"; "128k";
           "-vcodec"; "mpeg4";
           "-vb"; "1200k";
           "-f"; "mp4";
           "-nostats"; "-loglevel"; "error";
           tmp_fn];
        Logger.infof conf.logger "Done converting '%s'." local_fn;
        upload tmp_fn;
        Sys.remove tmp_fn
    end else begin
      upload entry.Entry.filename_local
    end
  in
  let set' = SetEntry.add entry set in
    commit_db conf set';
    set'

let avconv = ExternalCommand.make "avconv"

let create ~ftpfs ~local_rootdir ~local_dirs ~logger () =
  let ftpfs =
    match ftpfs with
      | `Ftp (url, password) ->
          let ftpfs =
            Ftp_fs.ftp_fs ~get_password:(fun _ -> password ()) url
          in
            (ftpfs :> Netfs.stream_fs)
      | `Ftpfs ftpfs -> ftpfs
  in
    {
      local_rootdir = local_rootdir;
      local_dirs = local_dirs;
      ftpfs = (ftpfs :> Netfs.stream_fs);
      logger = logger;
      avconv = avconv ();
    }

let from_conf () =
  let url = ref None in
  let local_rootdir = ref None in
  let local_dirs = ref [] in
  let args =
    [
      "-url",
      Arg.String (fun str -> url := Some str),
      "url Target ftp URL, like 'ftp://user@host/dir'";

      "-local-rootdir",
      Arg.String (fun str -> local_rootdir := Some str),
      "dir Root directory for the synchronisation.";

      "-local-dirs",
      Arg.String (fun str -> local_dirs := str :: !local_dirs),
      "dir Path relative to -local-rootdir to really synchronise (repeatable).";
    ]
  in
  let getopt name var =
    match !var with
      | Some str -> str
      | None ->
          failwith
            (Printf.sprintf "You must set %s." name)
  in
    args,
    fun ~logger ~password () ->
    create
      ~ftpfs:(`Ftp (getopt "-url" url, password))
      ~local_rootdir:(getopt "-local-rootdir" local_rootdir)
      ~local_dirs:!local_dirs
      ~logger ()

let sync conf =
  let set_local = scan_local conf in
  let set_remote = load_db conf in

  (* Do transformation to go from set_remote to set_local. *)
  let target_set = set_remote in

  (* Remove files. *)
  let target_set =
    SetEntry.fold
      (fun entry target_set -> remove conf target_set entry)
      (SetEntry.diff set_remote set_local)
      target_set
  in

  (* Upload new files. *)
  let target_set =
    SetEntry.fold
      (fun entry target_set -> upload conf target_set entry)
      (SetEntry.diff set_local set_remote)
      target_set
  in
    (* Final commit, just in case. *)
    if target_set <> set_remote then
      commit_db conf target_set

let close conf =
  ()
