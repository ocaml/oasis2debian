(******************************************************************************)
(* dlnasync: Synchronize your media collection with a DLNA server.            *)
(*                                                                            *)
(* Copyright (C) 2013, Sylvain Le Gall                                        *)
(*                                                                            *)
(* This library is free software; you can redistribute it and/or modify it    *)
(* under the terms of the GNU Lesser General Public License as published by   *)
(* the Free Software Foundation; either version 2.1 of the License, or (at    *)
(* your option) any later version, with the OCaml static compilation          *)
(* exception.                                                                 *)
(*                                                                            *)
(* This library is distributed in the hope that it will be useful, but        *)
(* WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY *)
(* or FITNESS FOR A PARTICULAR PURPOSE. See the file COPYING for more         *)
(* details.                                                                   *)
(*                                                                            *)
(* You should have received a copy of the GNU Lesser General Public License   *)
(* along with this library; if not, write to the Free Software Foundation,    *)
(* Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301 USA              *)
(******************************************************************************)

open OUnit2
open DLNASync

let create_dlnasync test_ctxt dn =
  let tmpdir = bracket_tmpdir test_ctxt in
  let srcdir = Filename.concat tmpdir "src" in
  let () =
    (* Populate source dir. *)
    (* TODO: use FileUtil.cp. *)
    assert_command ~ctxt:test_ctxt
      "cp" ["-R"; in_testdata_dir test_ctxt [dn]; srcdir]
  in
  let tgtdir = Filename.concat tmpdir "tgt" in
  let () = FileUtil.mkdir tgtdir in
  let upload_count = ref 0 in
  let ftpfs =
    (object
       (* Mock for the WNDR4500 ftp server, this generates almost the same kind
        * of errors, not 100% real but close enough to ensure we are testing the
        * target.
        *)
       inherit (Netfs.empty_fs "fake_ftp")

       val localfs = Netfs.local_fs ~root:tgtdir ()

       method read = localfs#read
       method write = incr upload_count; localfs#write
       method write_file = incr upload_count; localfs#write_file
       method remove = localfs#remove
       method readdir = localfs#readdir
       method rename = localfs#rename
       method mkdir flags dn =
         if List.mem `Path flags then
           raise (Unix.Unix_error(Unix.ENOENT, "", ""));
         localfs#mkdir flags dn

       method test flags fn test_type = false
     end)
  in
  let t =
    create
      ~ftpfs:(`Ftpfs (ftpfs :> Netfs.stream_fs))
      ~local_rootdir:srcdir
      ~local_dirs:[]
      ~logger:(LoggerOUnit.for_ounit2 test_ctxt)
      ()
  in
  let in_tgtdir = Filename.concat tgtdir in
    in_tgtdir, upload_count, t

let assert_tgt_file t fn =
  assert_bool
    (Printf.sprintf "Target file %s exists" fn)
    (remote_file_exists t fn)

let assert_not_tgt_file t fn =
  assert_bool
    (Printf.sprintf "Target file %s doesn't exist" fn)
    (not (remote_file_exists t fn))

let simple =
  "simple" >::
  (fun test_ctxt ->
     let _, upload_count, t = create_dlnasync test_ctxt "video1" in
     let call_avconv = ref 0 in
     let mock_avconv args =
       incr call_avconv;
       FileUtil.touch (List.hd (List.rev args))
     in
     let t = {t with avconv = ExternalCommand.mock "fake-avconv" mock_avconv} in
       (* Initial sync. *)
       sync t;
       assert_tgt_file t "/foo.mp4";
       assert_tgt_file t "/baz.mp4";
       assert_tgt_file t "/bar.mp4";
       assert_equal ~msg:"Conversion number." ~printer:string_of_int
         2 !call_avconv;

       (* Resync with no change. *)
       call_avconv := 0;
       upload_count := 0;
       sync t;
       assert_tgt_file t "/foo.mp4";
       assert_tgt_file t "/baz.mp4";
       assert_tgt_file t "/bar.mp4";
       assert_equal ~msg:"Conversion number." ~printer:string_of_int
         0 !call_avconv;
       assert_equal ~msg:"No extra upload." ~printer:string_of_int
         0 !upload_count;

       (* Add a file and sync. *)
       FileUtil.touch (Filename.concat t.local_rootdir "new.ogg");
       call_avconv := 0;
       sync t;
       assert_tgt_file t "/foo.mp4";
       assert_tgt_file t "/baz.mp4";
       assert_tgt_file t "/bar.mp4";
       assert_tgt_file t "/new.mp4";
       assert_equal ~msg:"Conversion number." ~printer:string_of_int
         1 !call_avconv;

       (* Check removal. *)
       Sys.remove (Filename.concat t.local_rootdir "new.ogg");
       call_avconv := 0;
       sync t;
       assert_tgt_file t "/foo.mp4";
       assert_tgt_file t "/baz.mp4";
       assert_tgt_file t "/bar.mp4";
       assert_not_tgt_file t "/new.mp4";
       assert_equal ~msg:"Conversion number." ~printer:string_of_int
         0 !call_avconv;

       close t;
       ())

let avprobe = Conf.make_exec "avprobe"

let real_conversion =
  "real_conversion" >::
  (fun test_ctxt ->
     let in_tgtdir, _, t = create_dlnasync test_ctxt "video2" in
     let () =
       sync t;
       close t;
       assert_tgt_file t "/test.mp4"
     in

     (* Check file is really a MP4. *)
     let buffer = Buffer.create 1024 in
       assert_command ~ctxt:test_ctxt
         ~foutput:(Stream.iter (Buffer.add_char buffer))
         ~use_stderr:true
         (avprobe test_ctxt) [in_tgtdir "test.mp4"];
       assert_bool
         "Generated file contains a MPEG4 video stream."
         (try
            let _i : int =
              BatString.find (Buffer.contents buffer) "Video: mpeg4"
            in
              true
          with Not_found ->
            false);

       ())

let subdir =
  "subdir" >::
  (fun test_ctxt ->
     let in_tgtdir, _, t = create_dlnasync test_ctxt "video3" in
       sync t;
       close t;
       assert_tgt_file t "/foo/bar.mp4";
       assert_tgt_file t "/foo/baz/bar2.mp4")

let () =
  run_test_tt_main
    ("readydlna-sync" >:::
     [
       simple;
       real_conversion;
       subdir;
     ])
