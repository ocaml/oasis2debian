(* OASIS_START *)
(* DO NOT EDIT (digest: 391f6c417e2ad5f8f44ee9cad1b009ee) *)
This is the README file for the dlnasync distribution.

(C) 2013 Sylvain Le Gall

Synchronize your media collection with a DLNA server.

This program helps to synchronize your video collection with a DLNA server
via ftp. It includes video conversion to mp4, using libav-tools.

It works with any FTP devices where you need to upload videos, after
conversion.

See the files INSTALL.txt for building and installation instructions. 

Home page: http://forge.ocamlcore.org/projects/dlnasync


(* OASIS_STOP *)
