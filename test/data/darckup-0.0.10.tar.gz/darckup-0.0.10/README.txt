(* OASIS_START *)
(* DO NOT EDIT (digest: 4ea8c153268b6357cec7164e2534351a) *)

darckup - Manage dar backups.
=============================

Software and library to manipulate a set of dar backups:

 - remove old backups
 - create new backups
 - upload to remote server
 - mulitple backups creation

See the file [INSTALL.txt](INSTALL.txt) for building and installation
instructions.

[Home page](https://forge.ocamlcore.org/projects/darckup/)

Copyright and license
---------------------

(C) 2015 Sylvain Le Gall

darckup is distributed under the terms of the GNU General Public License
version 3.

(* OASIS_STOP *)
